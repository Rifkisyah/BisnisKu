<?php $__env->startSection('page-title', 'Pengaturan Pembayaran'); ?>
<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-2xl space-y-6">
    <div class="mb-2 -ml-2">
        <a href="<?php echo e(route('settings.index')); ?>" class="btn-ghost"><svg class="w-4 h-4 inline-block -mt-0.5 mr-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" /></svg><?php echo e(__('messages.back') ?? 'Kembali'); ?></a>
    </div>

    <div class="card-feature p-8" x-data="{ mode: '<?php echo e(old('qris_mode', $paymentSetting->qris_mode)); ?>' }">
        <h3 class="type-subtitle-lg text-[var(--color-ink-deep)] mb-4 flex items-center">
            <svg class="w-6 h-6 mr-2 text-[var(--color-primary)]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h3m-3.75 3h15a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25v10.5A2.25 2.25 0 004.5 19.5z" /></svg>
            Pengaturan QRIS
        </h3>
        <form method="POST" action="<?php echo e(route('settings.payment.update')); ?>" enctype="multipart/form-data" class="space-y-6">
            <?php echo csrf_field(); ?>

            <div class="space-y-3">
                <label class="block type-body-sm-bold text-[var(--color-ink)] mb-1.5">Mode QRIS</label>
                
                <label class="flex items-start gap-3 p-4 border border-[var(--color-hairline-soft)] rounded-[var(--radius-xl)] cursor-pointer hover:bg-[var(--color-surface-soft)] transition-colors" :class="mode === 'manual' ? 'border-[var(--color-primary)] bg-[var(--color-primary)]/5' : ''">
                    <input type="radio" name="qris_mode" value="manual" x-model="mode" class="mt-1">
                    <div>
                        <p class="type-body-sm-bold text-[var(--color-ink)]">QRIS Manual / Statis</p>
                        <p class="type-caption text-[var(--color-slate)] mt-1">Gunakan gambar QRIS yang sudah ada, seperti QRIS DANA Business cetak. Pembayaran perlu dikonfirmasi manual oleh kasir.</p>
                    </div>
                </label>

                <label class="flex items-start gap-3 p-4 border border-[var(--color-hairline-soft)] rounded-[var(--radius-xl)] cursor-pointer hover:bg-[var(--color-surface-soft)] transition-colors" :class="mode === 'dynamic' ? 'border-[var(--color-primary)] bg-[var(--color-primary)]/5' : ''">
                    <input type="radio" name="qris_mode" value="dynamic" x-model="mode" class="mt-1">
                    <div>
                        <p class="type-body-sm-bold text-[var(--color-ink)]">QRIS Otomatis / Dinamis</p>
                        <p class="type-caption text-[var(--color-slate)] mt-1">QRIS dibuat otomatis untuk setiap transaksi. Pembayaran akan dikonfirmasi otomatis melalui webhook payment gateway.</p>
                    </div>
                </label>
            </div>

            
            <div x-show="mode === 'manual'" class="space-y-4 pt-4 border-t border-[var(--color-hairline-soft)]" x-cloak>
                <h4 class="type-body-sm-bold text-[var(--color-ink)]">Konfigurasi Manual</h4>
                <div>
                    <label class="block type-caption-bold text-[var(--color-slate)] mb-1.5">Gambar QRIS Statis</label>
                    <?php if(!empty($paymentSetting->manual_qris_image)): ?>
                        <img src="<?php echo e(asset($paymentSetting->manual_qris_image)); ?>" alt="QRIS" class="w-32 h-32 mb-2 rounded border border-gray-200 object-cover">
                    <?php endif; ?>
                    <input type="file" name="manual_qris_image" accept="image/*" class="input-field !p-1.5">
                    <p class="type-caption text-[var(--color-stone)] mt-1">Upload gambar barcode QRIS yang akan discan oleh customer.</p>
                </div>
            </div>

            
            <div x-show="mode === 'dynamic'" class="space-y-4 pt-4 border-t border-[var(--color-hairline-soft)]" x-cloak>
                <h4 class="type-body-sm-bold text-[var(--color-ink)]">Konfigurasi Midtrans QRIS Dinamis</h4>
                <div class="mb-4 p-4 bg-blue-50 text-blue-900 rounded-lg text-sm border border-blue-200 space-y-2">
                    <strong class="text-blue-800 font-bold block mb-1">📋 Panduan Setup Midtrans (Wajib Diisi):</strong>
                    <ol class="list-decimal list-inside space-y-1 ml-1">
                        <li>Daftar/Login ke <a href="https://dashboard.midtrans.com" target="_blank" class="underline font-bold text-blue-700">dashboard.midtrans.com</a></li>
                        <li>Pastikan metode pembayaran <strong>QRIS</strong> sudah aktif di menu <em>Settings → Payment Methods</em></li>
                        <li>Masuk ke menu <em>Settings → Access Keys</em>, lalu salin <strong>Server Key</strong> dan masukkan ke kolom di bawah.</li>
                        <li>Pada dashboard Midtrans, isi <strong>Payment Notification URL</strong> (Webhook) dengan URL ini: <br>
                            <code class="bg-blue-100 px-2 py-0.5 rounded text-xs font-mono text-blue-800 mt-1 inline-block"><?php echo e(url('/api/webhooks/midtrans')); ?></code>
                        </li>
                    </ol>
                    <p class="text-xs text-blue-700 mt-2 bg-blue-100/50 p-2 rounded border border-blue-200/50">
                        ℹ️ <strong>Otomatisasi Lingkungan:</strong> Sistem akan otomatis mendeteksi apakah Anda menggunakan mode <strong>Sandbox (Testing)</strong> atau <strong>Production (Live)</strong> berdasarkan awalan <em>Server Key</em> yang Anda masukkan (awalan <code>SB-</code> untuk Sandbox). Anda tidak perlu lagi mengubah file .env.
                    </p>
                </div>

                <div>
                    <label class="block type-caption-bold text-[var(--color-slate)] mb-1.5">Provider QRIS</label>
                    <select name="qris_provider" class="input-field">
                        <option value="">Pilih Provider</option>
                        <option value="midtrans" <?php echo e(old('qris_provider', $paymentSetting->qris_provider) == 'midtrans' ? 'selected' : ''); ?>>Midtrans</option>
                    </select>
                </div>

                <div>
                    <label class="block type-caption-bold text-[var(--color-slate)] mb-1.5">Merchant ID</label>
                    <input type="text" name="merchant_id" value="<?php echo e(old('merchant_id', $paymentSetting->merchant_id)); ?>" class="input-field" placeholder="Contoh: G123456789">
                </div>

                <div>
                    <label class="block type-caption-bold text-[var(--color-slate)] mb-1.5">
                        Server Key
                        <span class="text-[var(--color-stone)] font-normal">(Wajib — jangan share ke siapapun)</span>
                    </label>
                    <input type="password" name="server_key" value="<?php echo e(old('server_key')); ?>"
                        class="input-field font-mono text-sm"
                        placeholder="<?php echo e($paymentSetting->server_key ? '••••••••••••••••••• (sudah diisi)' : 'SB-Mid-server-XXXXXXXXXXXXXXXX'); ?>">
                    <p class="type-caption text-[var(--color-stone)] mt-1">Kosongkan jika tidak ingin mengubah key yang sudah tersimpan.</p>
                </div>

                <div>
                    <label class="block type-caption-bold text-[var(--color-slate)] mb-1.5">
                        Client Key
                        <span class="text-[var(--color-stone)] font-normal">(Untuk frontend)</span>
                    </label>
                    <input type="text" name="client_key" value="<?php echo e(old('client_key', $paymentSetting->client_key)); ?>"
                        class="input-field font-mono text-sm"
                        placeholder="<?php echo e($paymentSetting->client_key ? '••••••••••••••••••• (sudah diisi)' : 'SB-Mid-client-XXXXXXXXXXXXXXXX'); ?>">
                </div>

                <div>
                    <label class="block type-caption-bold text-[var(--color-slate)] mb-1.5">QRIS Acquirer</label>
                    <select name="qris_acquirer" class="input-field">
                        <option value="gopay" <?php echo e(old('qris_acquirer', $paymentSetting->qris_acquirer ?? 'gopay') == 'gopay' ? 'selected' : ''); ?>>
                            GoPay (Direkomendasikan — mendukung semua aplikasi QRIS)
                        </option>
                        <option value="airpay shopee" <?php echo e(old('qris_acquirer', $paymentSetting->qris_acquirer) == 'airpay shopee' ? 'selected' : ''); ?>>
                            ShopeePay
                        </option>
                    </select>
                    <p class="type-caption text-[var(--color-stone)] mt-1">Acquirer adalah pihak yang memproses QRIS. GoPay mendukung semua aplikasi QRIS (GoPay, OVO, Dana, dll).</p>
                </div>

                
                <?php if($paymentSetting->server_key): ?>
                <div class="p-3 bg-green-50 border border-green-200 rounded-lg flex items-center gap-3">
                    <svg class="w-5 h-5 text-green-600 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    <div>
                        <p class="type-caption-bold text-green-800">Server Key sudah tersimpan dan siap digunakan</p>
                        <p class="type-caption text-green-700">Mode Lingkungan: <?php echo e(!str_starts_with($paymentSetting->server_key, 'SB-') ? '🟢 Production (Live)' : '🟡 Sandbox (Testing)'); ?></p>
                    </div>
                </div>
                <?php endif; ?>
            </div>


            <button type="submit" class="btn-primary !py-2.5 !px-5 w-full mt-4"><?php echo e(__('messages.save')); ?> Pengaturan</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Office\Developer\Projects\Laravel\BisnisKu\resources\views/settings/payment.blade.php ENDPATH**/ ?>